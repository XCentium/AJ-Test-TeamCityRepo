﻿









CREATE VIEW [dbo].[vw_CategoryProduct] AS

	  SELECT DISTINCT
			 cat.id			as CategoryId,
			 p.id			as ProductId,
			 0				as SortOrder
		FROM [Product] P 
  INNER JOIN [TradeServicesProduct] TSP ON P.Name  = TSP.CustomerItemID
  INNER JOIN [Category] cat ON (   cat.ShortDescription = TSP.[TsCommodityLevel1]
								OR cat.ShortDescription = TSP.[TsCommodityLevel2]
								OR cat.ShortDescription = TSP.[TsCommodityLevel3]
								OR cat.ShortDescription = TSP.[TsCommodityLevel4]
								OR cat.ShortDescription = TSP.[TsCommodityLevel5]
		)