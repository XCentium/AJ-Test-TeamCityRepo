﻿CREATE VIEW dbo.vw_QualifyingOrders
AS
	SELECT DISTINCT *
	FROM DM_ECommerce..Vw_AllSalesLedgerHeaders
	WHERE OrderStatus NOT IN ('X','$')
	-- Beginning of month 24 months ago
	AND OrderDate >= CAST(
							CAST(DATEPART(YEAR, GETDATE()) - 2 AS VARCHAR(4))
							+ '-' + CAST(DATEPART(MONTH, GETDATE()) AS VARCHAR(2))
							+ '-01' AS DATETIME)