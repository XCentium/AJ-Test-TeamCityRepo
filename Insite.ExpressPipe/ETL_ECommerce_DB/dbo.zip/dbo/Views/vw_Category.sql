﻿










CREATE VIEW [dbo].[vw_Category] AS

	WITH c1 AS
	(
		SELECT DISTINCT
			--Temporarily commenting as Insite ECommerce only supports two levels.. 
			--Using Level3 and Level5
			--Later needs to use it when needed 
			[dbo].[fn_ScrubData]([TsCommodityLevel1]) Level1,
			[dbo].[fn_ScrubData]([TsCommodityLevel3]) Level2--,
			--[dbo].[fn_ScrubData]([TsSchemaLevel2]) Level3,
			--[dbo].[fn_ScrubData]([TsSchemaLevel4]) Level4,
			--[dbo].[fn_ScrubData]([TsSchemaLevel5]) Level5,
		FROM TradeServicesProduct
	)
		SELECT 
			0 Level, 
			'' ParentPath, 
			Level1 Path, 
			Level1 CategoryName 
		FROM C1 WHERE Level1 <> ''
	UNION 
		SELECT 
			1 Level, 
			Level1 ParentPath, 
			Level1  + '|' + Level2 Path, 
			Level2 CategoryName 
		FROM C1 WHERE Level2 <> ''
	--UNION 
	--	SELECT 
	--		2 Level, 
	--		Level1 + '|' + Level2 ParentPath, 
	--		Level1 + '|' + Level2 + '|' + Level3 Path, 
	--		Level3 CategoryName
	--	FROM C1 WHERE Level3 <> ''
	--UNION 
	--	SELECT 
	--		3 Level, 
	--		Level1 + '|' + Level2 + '|' + Level3 ParentPath, 
	--		Level1 + '|' + Level2 + '|' + Level3 + '|' + Level4 Path, 
	--		Level4 CategoryName
	--	FROM C1 WHERE Level4 <> ''
	--UNION 
	--	SELECT 
	--		4 Level, 
	--		Level1 + '|' + Level2 + '|' + Level3 + '|' + Level4 ParentPath, 
	--		Level1 + '|' + Level2 + '|' + Level3 + '|' + Level4 + '|' + Level5 Path, 
	--		Level5 CategoryName
	--	FROM C1 WHERE Level5 <> ''