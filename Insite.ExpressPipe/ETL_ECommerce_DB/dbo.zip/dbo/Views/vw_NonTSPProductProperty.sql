﻿







CREATE VIEW [dbo].[vw_NonTSPProductProperty]
AS
    SELECT [ERPNumber] ERPPartNo, 'ManufacturerName' Name, ManufacturerName Value FROM vw_NonTradeServiceProductData WHERE ISNULL(ManufacturerName, '') <> ''
    UNION SELECT [ERPNumber] ERPPartNo, 'Stock' Name, CASE WHEN [Stock_NonStock] = 'STOCK' THEN 'YES' ELSE 'NO' END Value FROM vw_NonTradeServiceProductData WHERE ISNULL([Stock_NonStock], '') <> ''
	UNION SELECT [ERPNumber] ERPPartNo, 'IsNonTSP' Name, 'Yes' Value FROM vw_NonTradeServiceProductData