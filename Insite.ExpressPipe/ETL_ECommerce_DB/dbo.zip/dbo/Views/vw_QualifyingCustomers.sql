﻿



CREATE VIEW [dbo].[vw_QualifyingCustomers]
AS
	  SELECT DISTINCT 
		 C.* 
	FROM [DM_ECommerce]..[Customer] C
	JOIN [dbo].[vw_QualifyingOrders] QO 
	  ON (C.[CustomerNo] = QO.[BillToNo] OR C.[CustomerNo] = QO.[ShipToNo])
	 AND C.ETLSourceId = QO.ETLSourceId
	 AND C.[ExcludeFromIndex] = 0