﻿








CREATE VIEW [dbo].[vw_ProductProperty]
AS
    SELECT CustomerItemId ERPPartNo, 'CustomerManufacturerName' Name, CustomerManufacturerName Value FROM dbo.TradeServicesProduct WHERE ISNULL(CustomerManufacturerName, '') <> ''
    UNION SELECT CustomerItemId ERPPartNo, 'CustomerManufacturerPartNumber' Name, CustomerManufacturerPartNumber Value FROM dbo.TradeServicesProduct WHERE ISNULL(CustomerManufacturerPartNumber, '') <> ''
    UNION SELECT CustomerItemId ERPPartNo, 'CustomerDescription' Name, CustomerDescription Value FROM dbo.TradeServicesProduct WHERE ISNULL(CustomerDescription, '') <> ''
    UNION SELECT CustomerItemId ERPPartNo, 'CustomerUPC' Name, CAST(CustomerUPC AS VARCHAR(20)) Value FROM dbo.TradeServicesProduct WHERE ISNULL(CustomerUPC, 0) <> 0
    UNION SELECT CustomerItemId ERPPartNo, 'CustomerPriceLine' Name, CustomerPriceLine Value FROM dbo.TradeServicesProduct WHERE ISNULL(CustomerPriceLine, '') <> ''
	UNION SELECT CustomerItemId ERPPartNo, 'CustomerPC' Name, CustomerPC Value FROM dbo.TradeServicesProduct WHERE ISNULL(CustomerPC, '') <> ''
	UNION SELECT CustomerItemId ERPPartNo, 'CustomerStatus' Name, CAST(ISNULL(CustomerStatus,0) as Varchar(10)) Value FROM dbo.TradeServicesProduct 
    UNION SELECT CustomerItemId ERPPartNo, 'ManufacturerName' Name, ManufacturerName Value FROM dbo.TradeServicesProduct WHERE ISNULL(ManufacturerName, '') <> ''
    UNION SELECT CustomerItemId ERPPartNo, 'ProductName' Name, ProductName Value FROM dbo.TradeServicesProduct WHERE ISNULL(ProductName, '') <> ''
    UNION SELECT CustomerItemId ERPPartNo, 'BrandName' Name, BrandName Value FROM dbo.TradeServicesProduct WHERE ISNULL(BrandName, '') <> ''
	--This property "SeriesModelFigureNumber" moved to attribute table 
	--UNION SELECT CustomerItemId ERPPartNo, 'SeriesModelFigureNumber' Name, SeriesModelFigureNumber Value FROM dbo.TradeServicesProduct WHERE ISNULL(SeriesModelFigureNumber, '') <> ''
    UNION SELECT CustomerItemId ERPPartNo, 'AdditionalInformation' Name, AdditionalInformation Value FROM dbo.TradeServicesProduct WHERE ISNULL(AdditionalInformation, '') <> ''
    UNION SELECT CustomerItemId ERPPartNo, 'PackageVolume' Name, CAST(PackageVolume AS VARCHAR(20)) Value FROM dbo.TradeServicesProduct WHERE ISNULL(PackageVolume, 0) <> 0
    UNION SELECT CustomerItemId ERPPartNo, 'CountryOfOrigin' Name, CountryOfOrigin Value FROM dbo.TradeServicesProduct WHERE ISNULL(CountryOfOrigin, '') <> ''
    UNION SELECT CustomerItemId ERPPartNo, 'LeadFree' Name, LeadFree Value FROM dbo.TradeServicesProduct WHERE ISNULL(LeadFree, '') <> ''
    UNION SELECT CustomerItemId ERPPartNo, 'MercuryFree' Name, MercuryFree Value FROM dbo.TradeServicesProduct WHERE ISNULL(MercuryFree, '') <> ''
    UNION SELECT CustomerItemId ERPPartNo, 'WaterSenseSaver' Name, WaterSenseSaver Value FROM dbo.TradeServicesProduct WHERE ISNULL(WaterSenseSaver, '') <> ''
    UNION SELECT CustomerItemId ERPPartNo, 'EnergyStarRated' Name, EnergyStarRated Value FROM dbo.TradeServicesProduct WHERE ISNULL(EnergyStarRated, '') <> ''
	UNION SELECT CustomerItemId ERPPartNo, 'CommodityGeneric' Name, CommodityGeneric Value FROM dbo.TradeServicesProduct WHERE ISNULL(CommodityGeneric, '') <> ''
	UNION SELECT CustomerItemId ERPPartNo, 'TSCommentsForCustomer' Name, TSCommentsForCustomer Value FROM dbo.TradeServicesProduct WHERE ISNULL(TSCommentsForCustomer, '') <> ''
    UNION SELECT CustomerItemId ERPPartNo, 'MfrItemPage' Name, MfrItemPage Value FROM dbo.TradeServicesProduct WHERE ISNULL(MfrItemPage, '') <> ''
    UNION SELECT CustomerItemId ERPPartNo, 'AdditionalUrl2' Name, AdditionalUrl2 Value FROM dbo.TradeServicesProduct WHERE ISNULL(AdditionalUrl2, '') <> ''
	--UNION SELECT CustomerItemId ERPPartNo, 'IsNonTSP' Name, 'No' Value FROM dbo.TradeServicesProduct 