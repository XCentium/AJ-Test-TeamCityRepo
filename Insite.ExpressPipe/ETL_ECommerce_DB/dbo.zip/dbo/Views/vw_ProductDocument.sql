﻿

CREATE VIEW [dbo].[vw_ProductDocument]
AS
    WITH Flattened AS
    (
        SELECT CustomerItemID ERPProductNo, 'MfrCatalogDocument' Name, MfrCatalogDocument URL 
            FROM vw_TradeServicesProduct P WHERE ISNULL(MfrCatalogDocument,'') <> ''
        UNION SELECT CustomerItemID ERPProductNo, 'MfrSpecificationTechnicalDocument' Name, MfrSpecificationTechnicalDocument URL 
            FROM vw_TradeServicesProduct P WHERE ISNULL(MfrSpecificationTechnicalDocument,'') <> ''
		UNION SELECT CustomerItemID ERPProductNo, 'MfrItemDataDocument' Name, MfrItemDataDocument URL 
            FROM vw_TradeServicesProduct P WHERE ISNULL(MfrItemDataDocument,'') <> ''
        UNION SELECT CustomerItemID ERPProductNo, 'MfrMsdsDocument' Name, MfrMsdsDocument URL 
            FROM vw_TradeServicesProduct P WHERE ISNULL(MfrMsdsDocument,'') <> ''
        UNION SELECT CustomerItemID ERPProductNo, 'MfrInstallationOperatorDocument' Name, MfrInstallationOperatorDocument URL
            FROM vw_TradeServicesProduct P WHERE ISNULL(MfrInstallationOperatorDocument,'') <> ''
    )
    SELECT 
        F.ErpProductNo,
        F.Name,
        F.URL,
        P.ParameterValue
    FROM Flattened F
    JOIN ETLParameter P ON P.ParameterGroup = 'vw_ProductDocumentName'
                       AND P.ParameterName = F.Name