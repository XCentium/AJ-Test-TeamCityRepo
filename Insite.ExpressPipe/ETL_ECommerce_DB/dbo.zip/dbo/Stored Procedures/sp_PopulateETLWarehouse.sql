﻿
CREATE PROCEDURE [dbo].[sp_PopulateETLWarehouse]
(
	@ETLSourceID VARCHAR(50),
	@UserName VARCHAR(50)
)
AS
-- =============================================
-- Author:		Venkatesan PS
-- Create date: 15th July 2015
-- Description:	This Procedure is created to populate the 
--               Warehouse Data in to the Warehouse Table 
--				 Morsco.com --> ETL DB --> Insite ExpressPipe DB
--	FOR Testing EXEC [sp_PopulateETLWarehouse] 'EXP','MyTestUser'
-- =============================================
BEGIN
		SET NOCOUNT ON;
		DECLARE @CountryID UNIQUEIDENTIFIER = (SELECT Id FROM [Insite.ExpressPipe].dbo.Country C WHERE C.ISOCode3 = 'USA')

		TRUNCATE TABLE [dbo].[Warehouse];

		;WITH DupeBranch AS
		(
			   SELECT 
					  Row_Number() OVER (PARTITION BY BranchId ORDER BY ExportDate DESC) RowNumber,
					  *
			   FROM DM_ECommerce..Branch
			   WHERE EtlSourceId = @ETLSourceID
		)
		INSERT INTO [dbo].[Warehouse]
			([Id]
			,[Name]
			,[Description]
			,[Address1]
			,[Address2]
			,[City]
			,[State]
			,[PostalCode]
			,[ContactName]
			,[Phone]
			,[ShipSite]
			,[DeactivateOn]
			,[IsDefaultWarehouse]
			,[CountryId]
			,[CreatedOn]
			,[CreatedBy]
			,[ModifiedOn]
			,[ModifiedBy])
		SELECT 
			NEWID() Id
			,Name + '(' + BranchID + ')'
			,'' [Description]
			,ISNULL([Address1],'')
			,ISNULL([Address2],'')
			,ISNULL([City],'')
			,ISNULL([State],'')
			,ISNULL(Zip,'') [PostalCode]
			,ISNULL([BranchManager],'') ContactName
			,ISNULL([PhoneNumber],'') Phone
			,ISNULL(BranchId,'') ShipSite
			,CASE WHEN [LiveBranchFlag] = 'N' THEN GETDATE() ELSE NULL END [DeactivateOn]
			,0 [IsDefaultWarehouse]
			,@CountryId CountryId
			,GETDATE() CreatedOn
			,@UserName CreatedBy
			,Getdate() ModifiedOn
			,@UserName ModifiedBy
		FROM DupeBranch 
		WHERE Rownumber = 1
END