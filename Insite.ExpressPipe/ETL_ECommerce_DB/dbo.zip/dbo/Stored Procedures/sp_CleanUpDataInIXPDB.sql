﻿
CREATE PROCEDURE [dbo].[sp_CleanUpDataInIXPDB] 
-- =============================================
--PROCEDURE:	sp_CleanUpDataInIXPDB
-- Author:		Venkatesan PS
-- Create date: 15th July 2015
-- Description:	This Procedure will delete all the records from the product and 
--				related tables so we can repopulate the data after cleanup
-- =============================================
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY
		BEGIN TRANSACTION

		--DELETE FROM [Insite.ExpressPipe].[dbo].[OrderLine]
		
		TRUNCATE TABLE [Insite.ExpressPipe].[dbo].[ProductAttributeValue]
	
		TRUNCATE TABLE [Insite.ExpressPipe].[dbo].[CategoryAttributeType]
	
		TRUNCATE TABLE [Insite.ExpressPipe].[dbo].[ProductUnitOfMeasure]
	
		TRUNCATE TABLE [Insite.ExpressPipe].[dbo].[ProductProperty]
	
		TRUNCATE TABLE [Insite.ExpressPipe].[dbo].[CategoryProduct]
	
		TRUNCATE TABLE [Insite.ExpressPipe].[dbo].[Content]
	
		TRUNCATE TABLE [Insite.ExpressPipe].[dbo].[Document]
	
		DELETE FROM [Insite.ExpressPipe].[dbo].[ContentManager]
	
		DELETE FROM [Insite.ExpressPipe].[dbo].[DocumentManager]
	
		TRUNCATE TABLE [Insite.ExpressPipe].[dbo].[CategoryProduct]
	
		TRUNCATE TABLE [Insite.ExpressPipe].[dbo].[ProductSpecification]
	
		DELETE FROM [Insite.ExpressPipe].[dbo].[Specification]
	
		DELETE FROM [Insite.ExpressPipe].[dbo].[Product]
	
		DELETE FROM [Insite.ExpressPipe].[dbo].[Category]

		--DELETE FROM [Insite.ExpressPipe].[dbo].[Customer]
	
		DELETE FROM [Insite.ExpressPipe].[dbo].[AttributeType]
	
		DELETE FROM [Insite.ExpressPipe].[dbo].[AttributeValue]
	
		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		PRINT ERROR_MESSAGE();
		ROLLBACK TRANSACTION;
	END CATCH
END