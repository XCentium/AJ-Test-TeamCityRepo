﻿CREATE PROCEDURE [dbo].[sp_UpdateProductWithDocumentManagerID]
(
	@ETLSourceID VARCHAR(50),
	@UserName VARCHAR(50)
)
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @RC int

	BEGIN TRY
		BEGIN TRANSACTION

		Update P 
			SET P.DocumentManagerId = DM.Id
		FROM Product P
			INNER JOIN DocumentManager DM
				ON (P.Name = DM.Name)
		
		--EXECUTE @RC = [dbo].[sp_PopulateInsiteProduct] 
		--   @ETLSourceID
		--  ,@UserName
	
		COMMIT TRANSACTION
	END TRY
	BEGIN Catch
		PRINT ERROR_MESSAGE()
		ROLLBACK TRANSACTION
	END Catch;

END