﻿


CREATE PROCEDURE [dbo].[sp_PopulateETLOrderHistory]
--
-- Name:	sp_PopulateETLOrderHistory
-- Descr:	Populate ETL Order History and Order History Line
-- Created:	7/28/2015 Matt Glover XCentium
-- Altered:
-- Test With: exec sp_PopulateETLOrderHistory 'EXP', 'ServiceUser'
(
	@EtlSourceID VARCHAR(5),
	@User VARCHAR(100)
)
AS 
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS OFF;
	SET XACT_ABORT ON;
	
	DECLARE @SentinelDate DATETIME2 = '1900-01-01';
	DECLARE @ErrorMessage VARCHAR(100);
select '1', getdate()
	--==========================================================================================================
	-- Delete current tables
	--==========================================================================================================
		
	-- Drop FK constraints so we can truncate -- saves minutes
	ALTER TABLE [dbo].[OrderHistoryLine] DROP CONSTRAINT [FK_OrderHistoryLine_OrderHistory]

	--If we can truncate, they're not logged, so transaction should not help
	TRUNCATE TABLE OrderHistoryLine
	TRUNCATE TABLE OrderHistory
		
	-- Re-add FK Constraints
	ALTER TABLE [dbo].[OrderHistoryLine]  WITH NOCHECK ADD  CONSTRAINT [FK_OrderHistoryLine_OrderHistory] FOREIGN KEY([OrderHistoryId])
	REFERENCES [dbo].[OrderHistory] ([Id])
	ON DELETE CASCADE

	--==========================================================================================================
	-- Insert OrderHistory for rolled up 'Master' Orders
	--==========================================================================================================
	-- Some fields (like address and name) need consistent information from a single row.  We'll use the lowest generation row
	-- That's what these first 2 CTEs do
	;WITH DupOrder AS
	(
		SELECT ROW_NUMBER() OVER (Partition By ERPOrderNo ORDER BY GenId) [Row],
			H.[ERPOrderNo],
			'' [WebOrderNumber],									--TODO: Set from chosen field
			ISNULL(H.[OrderDate],@SentinelDate) [OrderDate],
			ISNULL(H.OrderStatus,'') [OrderStatus],
			ISNULL(H.BillToNo,'') [BillToNo],
			ISNULL(H.ShipToNo,'') CustomerSequence,
			ISNULL(H.GenId,0) [GenId],
			dbo.fn_ScrubData2(ISNULL(H.CustomerPoNo, '')) [CustomerPoNo],
			'USD' [CurrencyCode],
			ISNULL(H.TermsCode,'') [TermsCode],
			ISNULL(H.BillToName,'') [BillToName],
			ISNULL(H.BillToAddressLine1,'') [BillToAddressLine1],
			ISNULL(H.BillToAddressLine2,'')  [BillToAddressLine2],
			ISNULL(H.BillToAddressCity,'') [BillToAddressCity],
			ISNULL(H.BillToAddressState,'') [BillToAddressState],
			ISNULL(H.BillToAddressPostalCode,'') [BillToAddressPostalCode],
			'US' [BTCountry],
			ISNULL(H.ShipToAddressLine1,'') [ShipToAddressLine1],
			ISNULL(H.ShipToAddressLine2,'') [ShipToAddressLine2],
			ISNULL(H.ShipToName,'') [ShipToName],
			ISNULL(H.ShipToCity,'') [ShipToCity],
			ISNULL(H.ShipToState,'') [ShipToState],
			ISNULL(H.ShipToPostalCode,'') [ShipToPostalCode],
			'US' [STCountry],
			ISNULL(H.OrderedBy,'') [OrderedBy],
			ISNULL(B.BranchManager,'') BranchManager
			FROM ETL_Ecommerce..vw_QualifyingOrders H
			LEFT JOIN DM_ECommerce.dbo.Branch B (NOLOCK) ON B.BranchID = H.ShipBranch
			WHERE H.ETLSourceID = @ETLSourceId
	),
	FirstGenOrder AS
	(
		SELECT *
		FROM DupOrder
		WHERE [Row] = 1
	),
	-- This CTE is everything that needs to roll up, except OrderStatus
	SummarizedOrder0 AS
	(
		SELECT 
			H.ERPOrderNo,
			-- Going to do Ship Code if all generations are the same.  Otherwise Multiple(3)
			ISNULL(COUNT(DISTINCT H.ShipVia), 0) ShipViaCount,
			ISNULL(MAX(H.ShipVia), '') MaxShipVia,
			ISNULL(SUM(H.FreightIn), 0) + ISNULL(SUM(H.FreightOut), 0) + ISNULL(SUM(H.HandlingIn), 0) + ISNULL(SUM(H.HandlingOut), 0) ShippingAndHandling,
			ISNULL(SUM(H.OrderSubTotal), 0) OrderSubTotal,
			ISNULL(SUM(H.TotalDiscount), 0) TotalDiscount,
			ISNULL(SUM(H.TotalTax), 0) TotalTax,
			ISNULL(SUM(H.OrderTotalAmount), 0) OrderTotalAmount,
			-- Makes a comma-separated list of the distinct OrderStatus values for all generations.
			SUBSTRING(REPLACE(
				(
					SELECT ',' + H2.OrderStatus AS 'data()'
					FROM ETL_Ecommerce..vw_QualifyingOrders H2
					WHERE H2.ETLSourceID = @ETLSourceID
					AND H2.ERPOrderNo = H.ERPORderNo
					GROUP BY H2.OrderStatus
					FOR XML PATH('')
				)
			, ' ', ''), 2, 4000) OrderStatuses,
			-- Makes a comma-separated list of distinct Salespeople
			(
				SELECT SalespersonName + ',' AS 'data()'
				FROM 
				(
					SELECT DISTINCT COALESCE(SP.SalespersonName, H2.InsideSalesPersonID) SalespersonName
					FROM ETL_Ecommerce..vw_QualifyingOrders H2
					LEFT JOIN DM_ECommerce.dbo.SalesPerson SP (NOLOCK) ON SP.EtlSourceID = H2.EtlSourceID
							                                            AND SP.SalesPersonId = H2.InsideSalesPersonID
					WHERE H2.ETLSourceID = @EtlSourceID
					AND H2.ERPOrderNo = H.ErpOrderNo
					UNION 
					SELECT DISTINCT COALESCE(SP.SalespersonName, H2.OutsideSalesPersonID) SalespersonName
					FROM ETL_Ecommerce..vw_QualifyingOrders H2
					LEFT JOIN DM_ECommerce.dbo.SalesPerson SP (NOLOCK) ON SP.EtlSourceID = H2.EtlSourceID
							                                            AND SP.SalesPersonId = H2.OutsideSalesPersonID
					WHERE H2.ETLSourceID = @EtlSourceID
					AND H2.ERPOrderNo = H.ERPOrderNo
				) AS Q
				FOR XML PATH('')
			) Salespeople
		FROM ETL_Ecommerce..vw_QualifyingOrders H
		--JOIN DM_ECommerce.DBO.LedgerHeaders LH (NOLOCK) ON LH.ETLSourceID = H.ETLSourceID
		--		                                AND LH.ERPOrderNo = H.ERPOrderNO
		WHERE H.ETLSourceID = @ETLSourceId
		GROUP BY H.ERPOrderNo
	),
	SummarizedOrder AS
	(
		SELECT
			S.ERPOrderNo,
			CASE WHEN S.ShipViaCount = 0 THEN ''
				WHEN S.ShipViaCount = 1 THEN S.MaxShipVia
				ELSE 'Multiple(' + CAST(S.ShipViaCount AS VARCHAR(10)) + ')'
			END [ShipCode],
			S.ShippingAndHandling,
			S.OrderSubTotal,
			S.TotalDiscount,
			S.TotalTax,
			S.OrderTotalAmount,
			-- When there is only 1 orderstatus and it is I, master order is invoiced, else it's not (and any random status will work).
			CASE 
				WHEN dbo.fn_GetCsvCount(S.OrderStatuses) = 1 AND dbo.fn_CsvContains(S.OrderStatuses, 'I') = 1 THEN 'I'
				ELSE 'C'
			END OrderStatus,
			CASE 
				WHEN LEN(S.Salespeople) < 2 THEN '' 
				ELSE SUBSTRING(S.Salespeople,1,LEN(S.Salespeople) - 1)
			END Salespeople
		FROM SummarizedOrder0 S
	)
	INSERT OrderHistory
		(
		--[Id],
		[ERPOrderNumber]
		,[WebOrderNumber]
		,[OrderDate]
		,[Status]
		,[CustomerNumber]
		,[CustomerSequence]
		,[CustomerPO]
		,[CurrencyCode]
		,[Terms]
		,[ShipCode]
		,[Salesperson]
		,[BTCompanyName]
		,[BTAddress1]
		,[BTAddress2]
		,[BTCity]
		,[BTState]
		,[BTPostalCode]
		,[BTCountry]
		,[STCompanyName]
		,[STAddress1]
		,[STAddress2]
		,[STCity]
		,[STState]
		,[STPostalCode]
		,[STCountry]
		,[Notes]
		,[ProductTotal]
		,[DiscountAmount]
		,[ShippingAndHandling]
		,[OtherCharges]
		,[TaxAmount]
		,[OrderTotal]
		,[ModifiedOn]
		,[ConversionRate]
		,[CreatedOn]
		,[CreatedBy]
		,[ModifiedBy])
	SELECT
		O1.[ERPOrderNo],
		O1.[WebOrderNumber],								--TODO: Set from chosen field
		O1.[OrderDate] [OrderDate],
		O2.OrderStatus [Status],
		O1.BillToNo [CustomerNumber],		
		O1.[CustomerSequence],
		dbo.fn_ScrubData2(O1.CustomerPoNo) [CustomerPO],
		O1.CurrencyCode [CurrencyCode],
		O1.TermsCode [Terms],
		O2.ShipCode,
		O2.Salespeople [Salesperson],
		O1.BillToName [BTCompanyName],
		dbo.fn_ScrubData2(O1.BillToAddressLine1) [BTAddress1],
		dbo.fn_ScrubData2(O1.BillToAddressLine2)  [BTAddress2],
		O1.BillToAddressCity [BTCity],
		O1.BillToAddressState [BTState],
		O1.BillToAddressPostalCode [BTPostalCode],
		O1.BTCountry,
		dbo.fn_ScrubData2(O1.ShipToAddressLine1) [ShipToAddress1],
		dbo.fn_ScrubData2(O1.ShipToAddressLine1) [ShipToAddress2],
		dbo.fn_ScrubData2(O1.ShipToName) [STCompanyName],
		O1.ShipToCity [STCity],
		O1.ShipToState [STState],
		O1.ShipToPostalCode [STPostalCode],
		O1.STCountry [STCountry],
		dbo.fn_ScrubData2(O1.OrderedBy) [Notes],
		O2.OrderSubTotal [ProductTotal], 
		O2.TotalDiscount [DiscountAmount],
		O2.ShippingAndHandling,
		0 [OtherCharges],
		O2.TotalTax [TaxAmount],
		O2.OrderTotalAmount [OrderTotal],
		GETDATE() [ModifiedOn],
		0 [ConversionRate],
		GETDATE() [CreatedOn],
		@User [CreatedBy],
		@User [ModifiedBy]
	FROM FirstGenOrder O1
	JOIN SummarizedOrder O2 ON O2.ERPOrderNo = O1.ERPOrderNo
select '2', getdate()
	--==========================================================================================================
	-- Insert OrderHistory for Generations
	--==========================================================================================================
	-- Avoid duplicate salespeople as a multiplier.  Happened twice, so assume we need to harden against.
	-- Are other salesperson references in this sp.  But not used as joined tables in main query.
	;WITH CTESalespersonWDup AS
	(
		SELECT ROW_NUMBER() OVER (Partition By SalespersonID Order By SalespersonName) Row,
			*
		FROM [DM_ECommerce]..Salesperson ISP (NOLOCK) 
		WHERE ISP.ETLSourceID = 'exp'
	),
	CTESalesperson AS
	(
		SELECT * FROM CTESalespersonWDup WHERE Row = 1
	)
	INSERT OrderHistory
		(
		--[Id],
		[ERPOrderNumber]
		,[WebOrderNumber]
		,[OrderDate]
		,[Status]
		,[CustomerNumber]
		,[CustomerSequence]
		,[CustomerPO]
		,[CurrencyCode]
		,[Terms]
		,[ShipCode]
		,[Salesperson]
		,[BTCompanyName]
		,[BTAddress1]
		,[BTAddress2]
		,[BTCity]
		,[BTState]
		,[BTPostalCode]
		,[BTCountry]
		,[STCompanyName]
		,[STAddress1]
		,[STAddress2]
		,[STCity]
		,[STState]
		,[STPostalCode]
		,[STCountry]
		,[Notes]
		,[ProductTotal]
		,[DiscountAmount]
		,[ShippingAndHandling]
		,[OtherCharges]
		,[TaxAmount]
		,[OrderTotal]
		,[ModifiedOn]
		,[ConversionRate]
		,[CreatedOn]
		,[CreatedBy]
		,[ModifiedBy])
	SELECT
		dbo.fn_GetGenerationOrderId(H.ERPOrderNo, H.GenId, H.Gen) [ERPOrderNumber],
		'' [WebOrderNumber],								--TODO: Set from chosen field
		ISNULL(H.OrderDate, @SentinelDate) [OrderDate],
		ISNULL(H.OrderStatus, '') [Status],
		ISNULL(H.BillToNo, '') [CustomerNumber],
		H.ShipToNo [CustomerSequence],
		dbo.fn_ScrubData2(ISNULL(H.CustomerPoNo, '')) [CustomerPO],
		'USD' [CurrencyCode],
		ISNULL(H.TermsCode,'') [Terms],
		ISNULL(H.ShipVia,'') [ShipCode],
		-- Concatenate what there is of looked up inside and outside salespeople
		SUBSTRING(COALESCE(ISP.SalesPersonName, H.InsideSalespersonID,'') 
			+ CASE WHEN COALESCE(ISP.SalesPersonName, H.InsideSalespersonID,'') <> '' 
					AND COALESCE(OSP.SalesPersonName, H.OutsideSalespersonID, '') <> '' 
					AND COALESCE(ISP.SalesPersonName, H.InsideSalespersonID,'') <> COALESCE(OSP.SalesPersonName, H.OutsideSalespersonID, '')
					THEN ',' ELSE '' END
			+ CASE WHEN COALESCE(ISP.SalesPersonName, H.InsideSalespersonID,'') <> COALESCE(OSP.SalesPersonName, H.OutsideSalespersonID, '')
				THEN COALESCE(OSP.SalesPersonName, H.OutsideSalespersonID, '') ELSE '' END, 
			1, 50) [Salesperson],
		ISNULL(H.BillToName, '') [BTCompanyName],
		ISNULL(H.BillToAddressLine1, '') [BTAddress1],
		dbo.fn_ScrubData2(ISNULL(H.BillToAddressLine2, ''))  [BTAddress2],
		ISNULL(H.BillToAddressCity, '') [BTCity],
		ISNULL(H.BillToAddressState, '') [BTState],
		ISNULL(H.BillToAddressPostalCode, '') [BTPostalCode],
		'US' BTCountry,
		CASE WHEN E.TranslatedValue = 'Will Call' THEN ISNULL(B.Address1,'')
			ELSE ISNULL(H.ShipToAddressLine1, '')
		END [ShipToAddress1],
		CASE WHEN E.TranslatedValue = 'Will Call' THEN ISNULL(B.Address2,'')
			ELSE ISNULL(H.ShipToAddressLine2, '')
		END [ShipToAddress2],
		CASE WHEN E.TranslatedValue = 'Will Call' THEN ISNULL(dbo.fn_ScrubData2(B.Name),'')
			ELSE ISNULL(dbo.fn_ScrubData2(H.ShipToName), '')
		END [STCompanyName],
   		CASE WHEN E.TranslatedValue = 'Will Call' THEN ISNULL(B.City,'')
			ELSE ISNULL(H.ShipToCity, '')
		END [STCity],
   		CASE WHEN E.TranslatedValue = 'Will Call' THEN ISNULL(B.State,'')
			ELSE ISNULL(H.ShipToState, '')
		END [STState],
		CASE WHEN E.TranslatedValue = 'Will Call' THEN ISNULL(B.Zip,'')
			ELSE ISNULL(H.ShipToPostalCode, '')
		END [STPostalCode],
		'US' [STCountry],
		dbo.fn_ScrubData2(ISNULL(H.OrderedBy, '')) [Notes],
		ISNULL(H.OrderSubTotal, 0) [ProductTotal],
		ISNULL(H.TotalDiscount, 0) [DiscountAmount],
		ISNULL(H.FreightIn, 0) + ISNULL(H.FreightOut, 0) + ISNULL(H.HandlingIn, 0) + ISNULL(H.HandlingOut, 0) [ShippingAndHandling],
		0 [OtherCharges],
		ISNULL(H.TotalTax, 0) [TaxAmount],
		ISNULL(H.OrderTotalAmount, 0) [OrderTotal],
		GETDATE() [ModifiedOn],
		0 [ConversionRate],
		GETDATE() [CreatedOn],
		@User [CreatedBy],
		@User [ModifiedBy]
	FROM ETL_Ecommerce..vw_QualifyingOrders H
	LEFT JOIN [DM_ECommerce]..Branch B (NOLOCK) ON B.ETLSourceID = H.EtlSourceId
			                            AND B.BranchID = H.ShipBranch
	LEFT JOIN ETLTranslation E ON E.ETLSourceID = H.EtlSourceId
			                    AND E.TargetColumn = 'ShipVia'
								AND E.TargetValue = H.ShipVia
	LEFT JOIN CTESalesperson ISP (NOLOCK) ON ISP.ETLSourceID = H.EtlSourceId
			                             AND ISP.SalesPersonID = H.InsideSalesPersonID
	LEFT JOIN CTESalesPerson OSP (NOLOCK) ON OSP.ETLSourceID = H.EtlSourceId
			                             AND OSP.SalesPersonID = H.OutsideSalesPersonID
	WHERE H.ETLSourceID = @ETLSourceID
select '3', getdate()
	--==========================================================================================================
	-- Get the IDs to be used in Merging
	--==========================================================================================================
	UPDATE New
		SET New.ID = Existing.ID
	FROM OrderHistory New
	JOIN [Insite.ExpressPipe]..OrderHistory Existing ON Existing.ErpOrderNumber = New.ERPOrderNumber
select '4', getdate()
	--==========================================================================================================
	-- Insert OrderHistoryLine for rolled up 'Master' orders
	--==========================================================================================================
	-- Discovered products are not unique
	;WITH p AS
	(
		SELECT ERPPartNo, MAX(BaseUnitOfMeasure) BaseUnitOfMeasure
		FROM DM_ECommerce.dbo.Product P (NOLOCK)
		WHERE P.ETLSourceId = @EtlSourceID
		GROUP BY ERPPartNo
	)
	INSERT OrderHistoryLine
		(
		--[Id],
		[OrderHistoryId]
		,[RequiredDate]
		,[LastShipDate]
		,[CustomerNumber]
		,[CustomerSequence]
		,[LineType]
		,[Status]
		,[LineNumber]
		,[ReleaseNumber]
		,[ProductERPNumber]
		,[CustomerProductNumber]
		,[LinePOReference]
		,[Description]
		,[Warehouse]
		,[Notes]
		,[QtyOrdered]
		,[QtyShipped]
		,[UnitOfMeasure]
		,[InventoryQtyOrdered]
		,[InventoryQtyShipped]
		,[UnitPrice]
		,[DiscountPercent]
		,[DiscountAmount]
		,[PromotionAmountApplied]
		,[LineTotal]
		,[RMAQtyRequested]
		,[RMAQtyReceived]
		,[CreatedOn]
		,[CreatedBy]
		,[ModifiedOn]
		,[ModifiedBy]
		)
	SELECT
		OH.Id [OrderHistoryId],
		NULL [RequiredDate],
		ISNULL(MAX(H.ShipDate), @SentinelDate) [LastShipDate],
		ISNULL(MAX(OH.CustomerNumber), '') [CustomerNumber],
		ISNULL(MAX(H.ShipToNo), '') [CustomerSequence],
		'' [LineType],
		'' [Status],
											-- Setting LineNumber and ReleaseNumber because OrderHistoryId, Line, ReleaseNumber must be 
											-- unique combination in Insite
		ISNULL(I.LineNum,0) [LineNumber],    
		ISNULL(I.ERPPartNo,'') [ReleaseNumber],

		ISNULL(I.ERPPartNo,'') [ProductERPNumber],
		'' [CustomerProductNumber],
		'' [LinePOReference],
		'' [Description], -- previously did this, the MAX(I.ErpPartName) eventually broke SQL performance -- dbo.fn_ScrubData2(ISNULL(MAX(I.ErpPartName),'')) [Description],
		'' [Warehouse],						-- May have multiple warehouses
		'' [Notes],
		ISNULL(MAX(I.OrderQuantity), 0) [QtyOrdered],
		SUM(ISNULL(I.ShippedQty, 0)) [QtyShipped],
		ISNULL(MAX(P.BaseUnitOfMeasure),'') [UnitOfMeasure],
		0 [InventoryQtyOrdered],
		0 [InventoryQtyShipped],
		ISNULL(MAX(I.UnitPrice),0) [UnitPrice],
		0 [DiscountPercent],
		0 [DiscountAmount],
		0 [PromotionAmountApplied],
		SUM(COALESCE(i.ShippedQty, i.OrderQuantity, 0) * ISNULL(I.UnitPrice,0)) [LineTotal],
		0 [RMAQtyRequested],
		0 [RMAQtyReceived],
		GETDATE() [CreatedOn],
		@ETLSourceId [CreatedBy],
		GETDATE() [ModifiedOn],
		@ETLSourceId [ModifiedBy]
	FROM ETL_Ecommerce..vw_QualifyingOrders H
	JOIN DM_ECommerce.dbo.LedgerLineItem I (NOLOCK) ON I.ETLSourceId = H.EtlSourceID
									AND I.ERPOrderNo = H.ERPOrderNo
									AND ISNULL(I.Gen,'') = ISNULL(H.Gen,'')
									AND ISNULL(I.GenID,'')  = ISNULL(H.GenId,'')
	JOIN OrderHistory OH (NOLOCK) ON OH.ERPOrderNumber =  H.ERPOrderNo
	LEFT JOIN P ON P.ERPPartNo = I.ErpPartNo
	WHERE I.ETLSourceID = @EtlSourceId
	AND I.ERPPartno IS NOT NULL
	GROUP BY OH.ERPOrderNumber, I.ErpPartNo, I.LineNum, OH.ID
select '5', getdate()
	--==========================================================================================================
	-- Insert OrderHistoryLine for Generation orders
	-- These are also rolled up by LineNo and Product -- appears to make LineNo unique which is necessary
	--==========================================================================================================
	;WITH p AS
	(
		SELECT ERPPartNo, MAX(BaseUnitOfMeasure) BaseUnitOfMeasure
		FROM DM_ECommerce.dbo.Product P (NOLOCK)
		WHERE P.ETLSourceId = @EtlSourceID
		GROUP BY ERPPartNo
	)
	INSERT OrderHistoryLine
		(
		--[Id],
		[OrderHistoryId]
		,[RequiredDate]
		,[LastShipDate]
		,[CustomerNumber]
		,[CustomerSequence]
		,[LineType]
		,[Status]
		,[LineNumber]
		,[ReleaseNumber]
		,[ProductERPNumber]
		,[CustomerProductNumber]
		,[LinePOReference]
		,[Description]
		,[Warehouse]
		,[Notes]
		,[QtyOrdered]
		,[QtyShipped]
		,[UnitOfMeasure]
		,[InventoryQtyOrdered]
		,[InventoryQtyShipped]
		,[UnitPrice]
		,[DiscountPercent]
		,[DiscountAmount]
		,[PromotionAmountApplied]
		,[LineTotal]
		,[RMAQtyRequested]
		,[RMAQtyReceived]
		,[CreatedOn]
		,[CreatedBy]
		,[ModifiedOn]
		,[ModifiedBy]
		)
	SELECT
		OH.Id [OrderHistoryId],
		NULL [RequiredDate],
		MAX(ISNULL(H.ShipDate, @SentinelDate)) [LastShipDate],
		MAX(OH.CustomerNumber) [CustomerNumber],
		MAX(H.ShipToNo) [CustomerSequence],
		'' [LineType],
		'' [Status],						-- Setting LineNumber and ReleaseNumber because OrderHistoryId, Line, ReleaseNumber must be 
											-- unique combination in Insite
		MAX(ISNULL(I.LineNum, 0)) [LineNumber],    
		I.ERPPartNo [ReleaseNumber],
		I.ERPPartNo [ProductERPNumber],
		'' [CustomerProductNumber],
		'' [LinePOReference],
		'' [Description], -- Previously did this, the MAX(I.ErpPartName) increased time of query to approx 1 hr dbo.fn_ScrubData2(MAX(ISNULL(I.ErpPartName,''))) [Description],
		'' [Warehouse],						-- May have multiple warehouses
		'' [Notes],
		MAX(ISNULL(I.OrderQuantity, 0)) [QtyOrdered],
		MAX(ISNULL(I.ShippedQty, 0)) [QtyShipped],
		MAX(ISNULL(P.BaseUnitOfMeasure,'')) [UnitOfMeasure],
		0 [InventoryQtyOrdered],
		0 [InventoryQtyShipped],
		MAX(ISNULL(I.UnitPrice,0)) [UnitPrice],
		0 [DiscountPercent],
		0 [DiscountAmount],
		0 [PromotionAmountApplied],
		MAX(COALESCE(ShippedQty, OrderQuantity, 0) * ISNULL(I.UnitPrice, 0)) [LineTotal],
		0 [RMAQtyRequested],
		0 [RMAQtyReceived],
		GETDATE() [CreatedOn],
		@ETLSourceId [CreatedBy],
		GETDATE() [ModifiedOn],
		@ETLSourceId [ModifiedBy]
	FROM ETL_Ecommerce..vw_QualifyingOrders H
	JOIN DM_ECommerce.dbo.LedgerLineItem I (NOLOCK) ON I.ETLSourceId = H.EtlSourceID
									AND I.ERPOrderNo = H.ERPOrderNo
									AND ISNULL(I.Gen,'') = ISNULL(H.Gen,'')
									AND ISNULL(I.GenID,'')  = ISNULL(H.GenId,'')
	JOIN OrderHistory OH (NOLOCK) ON OH.ERPOrderNumber = dbo.fn_GetGenerationOrderId(H.ERPOrderNo, H.GenId, H.Gen)
	LEFT JOIN P ON P.ERPPartNo = I.ErpPartNo
	WHERE I.ETLSourceID = @EtlSourceId
	AND I.ERPPartno IS NOT NULL
	GROUP BY I.ERPOrderNo, H.GenId, H.Gen, I.ErpPartNo, I.LineNum, OH.ID
select '6', getdate()
	--==========================================================================================================
	-- Get the IDs to be used in Merging
	--==========================================================================================================
	UPDATE New
		SET New.ID = Existing.ID
	FROM OrderHistoryLine New
	JOIN [Insite.ExpressPipe]..OrderHistoryLine Existing ON Existing.OrderHistoryId = New.OrderHistoryId
														AND Existing.ProductERPNumber = New.ProductERPNumber
															AND Existing.LineNumber = New.LineNumber
select '7', getdate()
END