﻿CREATE PROCEDURE sp_PopulateInsiteWarehouse
(
	@ETLSourceID VARCHAR(50),
	@UserName VARCHAR(50)
)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
		BEGIN TRANSACTION

			;MERGE [Insite.ExpressPipe]..Warehouse AS Target
			USING
			(
				SELECT * FROM ETL_Ecommerce..Warehouse AS Source
			) AS Source
			ON Target.Id = Source.Id
		WHEN MATCHED AND 
			(
				Target.Name <> Source.Name
				OR Target.Description <> Source.Description
				OR Target.Address1 <> Source.Address1
				OR Target.Address2 <> Source.Address2
				OR Target.City <> Source.City
				OR Target.State <> Source.State
				OR Target.PostalCode <> Source.PostalCode
				OR Target.ContactName <> Source.ContactName
				OR Target.Phone <> Source.Phone
				OR Target.ShipSite <> Source.ShipSite
				OR Target.DeactivateOn <> Source.DeactivateOn
				OR Target.IsDefaultWarehouse <> Source.IsDefaultWarehouse
				OR Target.CountryId <> Source.CountryId
			) THEN
			UPDATE SET 
				Target.Name = Source.Name,
				Target.Description = Source.Description,
				Target.Address1 = Source.Address1,
				Target.Address2 = Source.Address2,
				Target.City = Source.City,
				Target.State = Source.State,
				Target.PostalCode = Source.PostalCode,
				Target.ContactName = Source.ContactName,
				Target.Phone = Source.Phone,
				Target.ShipSite = Source.ShipSite,
				Target.DeactivateOn = Source.DeactivateOn,
				Target.IsDefaultWarehouse = Source.IsDefaultWarehouse,
				Target.CountryId = Source.CountryId,
				Target.ModifiedOn = Source.ModifiedOn,
				Target.ModifiedBy = Source.ModifiedBy
			WHEN NOT MATCHED BY TARGET THEN
			INSERT 
				(
			      Id,
			      Name,
			      Description,
			      Address1,
			      Address2,
			      City,
			      State,
			      PostalCode,
			      ContactName,
			      Phone,
			      ShipSite,
			      DeactivateOn,
			      IsDefaultWarehouse,
			      CountryId,
			      CreatedOn,
			      CreatedBy,
			      ModifiedOn,
			      ModifiedBy				)
			VALUES
			(
			   Source.Id,
			   Source.Name,
			   Source.Description,
			   Source.Address1,
			   Source.Address2,
			   Source.City,
			   Source.State,
			   Source.PostalCode,
			   Source.ContactName,
			   Source.Phone,
			   Source.ShipSite,
			   Source.DeactivateOn,
			   Source.IsDefaultWarehouse,
			   Source.CountryId,
			   Source.CreatedOn,
			   Source.CreatedBy,
			   Source.ModifiedOn,
			   Source.ModifiedBy			)
		WHEN NOT MATCHED BY Source THEN
			UPDATE SET Target.DeactivateOn = GETDATE();

		COMMIT TRANSACTION
	END TRY
	BEGIN Catch
		PRINT ERROR_MESSAGE()
		ROLLBACK TRANSACTION
	END Catch;

END