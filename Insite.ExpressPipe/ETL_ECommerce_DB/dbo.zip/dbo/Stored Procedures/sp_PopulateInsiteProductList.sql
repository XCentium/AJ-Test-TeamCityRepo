﻿CREATE PROCEDURE [dbo].[sp_PopulateInsiteProductList]
(
	@ETLSourceID VARCHAR(50),
	@UserName VARCHAR(50)
)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
		BEGIN TRANSACTION

			;MERGE [Insite.ExpressPipe].Custom.ProductList AS Target
			USING
			(
				SELECT * FROM ETL_Ecommerce..ProductList AS Source
			) AS Source
			ON Target.[ProductListId] = Source.[ProductListId]
		WHEN MATCHED AND 
			(
				Target.ProductListTypeId <> Source.ProductListTypeId
				OR Target.CustomerId <> Source.CustomerId
				OR Target.ProductId <> Source.ProductId
				OR Target.CustomerNumber <> Source.CustomerNumber
				OR Target.CustomerSequence <> Source.CustomerSequence
				OR Target.ProductErpNumber <> Source.ProductErpNumber
				OR Target.Frequency <> Source.Frequency
			) THEN
			UPDATE SET 
				Target.ProductListTypeId = Source.ProductListTypeId,
				Target.CustomerId = Source.CustomerId,
				Target.ProductId = Source.ProductId,
				Target.CustomerNumber = Source.CustomerNumber,
				Target.CustomerSequence = Source.CustomerSequence,
				Target.ProductErpNumber = Source.ProductErpNumber,
				Target.Frequency = Source.Frequency,
				Target.ModifiedOn = Source.ModifiedOn,
				Target.ModifiedBy = Source.ModifiedBy
			WHEN NOT MATCHED BY TARGET THEN
			INSERT 
				(
			      ProductListId,
			      ProductListTypeId,
			      CustomerId,
			      ProductId,
			      CustomerNumber,
			      CustomerSequence,
			      ProductErpNumber,
			      Frequency,
			      CreatedOn,
			      CreatedBy,
			      ModifiedOn,
			      ModifiedBy				)
			VALUES
			(
			   Source.ProductListId,
			   Source.ProductListTypeId,
			   Source.CustomerId,
			   Source.ProductId,
			   Source.CustomerNumber,
			   Source.CustomerSequence,
			   Source.ProductErpNumber,
			   Source.Frequency,
			   Source.CreatedOn,
			   Source.CreatedBy,
			   Source.ModifiedOn,
			   Source.ModifiedBy			)
		WHEN NOT MATCHED BY Source THEN
			DELETE;

		COMMIT TRANSACTION
	END TRY
	BEGIN Catch
		PRINT ERROR_MESSAGE()
		ROLLBACK TRANSACTION
	END Catch;

END