﻿CREATE PROCEDURE [dbo].[sp_PopulateETLProductList]
--
-- Name:      sp_PopulateETLProductList
-- Descr:     Populate ETL Product Lists
-- Created:   8/27/2015 Matt Glover XCentium
-- Note:    MUST BE RUN AFTER ETL ProductHistory POPULATION
-- Altered:
-- Test With: exec sp_PopulateETLProductList 'ServiceUser'
(
       @UserName VARCHAR(50) 
)
AS
BEGIN
       SET NOCOUNT ON
       SET XACT_ABORT ON

       DECLARE @24MonthsAgo DATETIME = CAST(
                                            CAST(DATEPART(YEAR, GETDATE()) - 2 AS VARCHAR(4))
                                            + '-' + CAST(DATEPART(MONTH, GETDATE()) AS VARCHAR(2))
                                            + '-01' AS DATETIME)

       DECLARE @ProductListTypeId UNIQUEIDENTIFIER = (SELECT Id FROM ProductListType WHERE ListType = 'ShipToCust24Mo');


       -- Previously Purchased Products - By Ship To Customer for last 24 months 
       INSERT ProductList 
       (
              ProductListTypeId, 
              CustomerId, 
              ProductId, 
              CustomerNumber, 
              CustomerSequence, 
              ProductErpNumber, 
              Frequency,
              CreatedOn,
              CreatedBy,
              ModifiedOn,
              ModifiedBy
       )
       SELECT 
              @ProductListTypeId, 
              C.ID, 
              P.ID, 
              O.CustomerNumber, 
              O.CustomerSequence, 
              L.ProductERPNumber, 
              COUNT(*) Frequency,
              GETDATE(),
              @UserName,
              GETDATE(),
              @UserName
       FROM [Insite.ExpressPipe]..OrderHistory O
       JOIN [Insite.ExpressPipe]..OrderHistoryLine L ON L.OrderHistoryID = O.ID
       JOIN [Insite.ExpressPipe]..Customer C ON C.CustomerNumber = O.CustomerNumber AND ISNULL(C.CustomerSequence,'') = ISNULL(O.CustomerSequence,'')
       JOIN [Insite.ExpressPipe]..Product P ON P.ERPNumber = L.ProductERPNumber
       WHERE O.OrderDate > @24MonthsAgo
       GROUP BY C.ID, P.ID, O.CustomerNumber, O.CustomerSequence, L.ProductERPNumber

       -- Previously Purchased Products - By Bill To Customer for last 24 months
       SET @ProductListTypeId = (SELECT Id FROM ProductListType WHERE ListType = 'BillToCust24Mo');

       INSERT ProductList 
       (
              ProductListTypeId, 
              CustomerId, 
              ProductId, 
              CustomerNumber, 
              CustomerSequence, 
              ProductErpNumber, 
              Frequency,
              CreatedOn,
              CreatedBy,
              ModifiedOn,
              ModifiedBy
       )
       SELECT 
              @ProductListTypeId, 
              C.ID, 
              P.ID, 
              O.CustomerNumber, 
              NULL, 
              L.ProductERPNumber, 
              COUNT(*) Frequency,
              GETDATE(),
              @UserName,
              GETDATE(),
              @UserName
       FROM [Insite.ExpressPipe]..OrderHistory O
       JOIN [Insite.ExpressPipe]..OrderHistoryLine L ON L.OrderHistoryID = O.ID
       -- Bill To Customer
       JOIN [Insite.ExpressPipe]..Customer C ON C.CustomerNumber = O.CustomerNumber AND ISNULL(C.CustomerSequence,'') = ''
       JOIN [Insite.ExpressPipe]..Product P ON P.ERPNumber = L.ProductERPNumber
       WHERE O.OrderDate > @24MonthsAgo
       GROUP BY C.ID, P.ID, O.CustomerNumber, L.ProductERPNumber


       --Popular Products - For all of Morsco for last 24 months
       SET @ProductListTypeId = (SELECT Id FROM ProductListType WHERE ListType = 'AllCust24Mo');
       
       INSERT ProductList 
       (
              ProductListTypeId, 
              CustomerId, 
              ProductId, 
              CustomerNumber, 
              CustomerSequence, 
              ProductErpNumber, 
              Frequency,
              CreatedOn,
              CreatedBy,
              ModifiedOn,
              ModifiedBy
       )
       SELECT 
              @ProductListTypeId, 
              NULL, 
              P.ID, 
              NULL, 
              NULL, 
              L.ProductERPNumber, 
              COUNT(*) Frequency,
              GETDATE(),
              @UserName,
              GETDATE(),
              @UserName

       FROM [Insite.ExpressPipe]..OrderHistory O
       JOIN [Insite.ExpressPipe]..OrderHistoryLine L ON L.OrderHistoryID = O.ID
       JOIN [Insite.ExpressPipe]..Product P ON P.ERPNumber = L.ProductERPNumber
       WHERE O.OrderDate > @24MonthsAgo
       GROUP BY P.ID, L.ProductERPNumber
END