﻿
CREATE PROCEDURE [dbo].[sp_PopulateETLWebSiteEtlSource] 
	-- Add the parameters for the stored procedure here
	@ETLSourceId as Varchar(50),
	@WebSiteName as Varchar(50),
	@UserName as Varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY
		BEGIN TRANSACTION

			TRUNCATE TABLE WebSiteEtlSource;
			INSERT WebSiteEtlSource (
				WebSiteId, 
				ETLSourceID
				) 
			SELECT 
				[Id], 
				@ETLSourceId
			FROM [Insite.ExpressPipe].[dbo].[WebSite] WHERE Name = @WebSiteName;

		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		PRINT ERROR_MESSAGE()
		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION --RollBack in case of Error
		THROW;
	END CATCH
END