﻿
CREATE PROCEDURE [dbo].[sp_CleanUpDataInETLDB] 
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY
		BEGIN TRANSACTION

		TRUNCATE TABLE [dbo].[ProductAttributeValue]
	
		TRUNCATE TABLE [dbo].[CategoryAttributeType]
	
		TRUNCATE TABLE [dbo].[ProductUnitOfMeasure]
	
		TRUNCATE TABLE [dbo].[ProductProperty]
	
		TRUNCATE TABLE [dbo].[CategoryProduct]
	
		TRUNCATE TABLE [dbo].[Content]
	
		TRUNCATE TABLE [dbo].[Document]
	
		DELETE FROM [dbo].[ContentManager]
	
		DELETE FROM [dbo].[DocumentManager]
	
		TRUNCATE TABLE [dbo].[CategoryProduct]
	
		TRUNCATE TABLE [dbo].[ProductSpecification]
	
		DELETE FROM [dbo].[Specification]
	
		DELETE FROM [dbo].[Product]
	
		DELETE FROM [dbo].[Category]

		--DELETE FROM [dbo].[Customer]
	
		DELETE FROM [dbo].[AttributeType]
	
		DELETE FROM [dbo].[AttributeValue]
	
		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		PRINT ERROR_MESSAGE();
		ROLLBACK TRANSACTION;
	END CATCH
END