﻿
--DROP PROCEDURE [dbo].[sp_PopulateETLCategory_CategoryProduct]

CREATE PROCEDURE [dbo].[sp_PopulateETLCategory_CategoryProduct]
(
	@ETLSourceID VARCHAR(50),
	@UserName VARCHAR(50)
)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @WebSiteId UNIQUEIDENTIFIER = NULL;
	DECLARE @ErrorMessage VARCHAR(100);
	DECLARE @UniqueURLSegment uniqueidentifier = NULL;
	DECLARE @DefaultCategoryID uniqueidentifier = NEWID();

	
	SET XACT_ABORT ON;

		SELECT @WebSiteId = dbo.fn_WebSiteForEtlSourceID(@EtlSourceId);

		IF @WebSiteId IS NULL
		BEGIN
			SET @ErrorMessage = 'No website found for Etl Source Id ' + @EtlSourceId;
			THROW 60000, @ErrorMessage,  1;
		END

--###############################################################################################################################
--						TABLE CATEGORY
--###############################################################################################################################		

		TRUNCATE TABLE Category

		INSERT INTO [dbo].[Category]
			( --ID
			[ParentId]
			,[WebSiteId]
			,[Name]
			,[ShortDescription]
			,[SmallImagePath]
			,[LargeImagePath]
			,[ActivateOn]
			,[DeactivateOn]
			,[UrlSegment]
			,[MetaKeywords]
			,[MetaDescription]
			,[SortOrder]
			,[ShowDetail]
			,[PageTitle]
			,[ContentManagerId]
			,[DocumentManagerId]
			,[ERPProductValues]
			,[IsFeatured]
			,[IsDynamic]
			,[RuleManagerId]
			,[ImageAltText]
			,[CreatedOn]
			,[CreatedBy]
			,[ModifiedOn]
			,[ModifiedBy]
			,[Path]
			,[ParentPath])
		SELECT
			--NewSequentialID(),
			NULL ParentId,
			ISNULL(@WebSiteId,'') WebSiteId,
			dbo.fn_ScrubData(C.CategoryName) Name,
			dbo.fn_ScrubData(C.CategoryName) ShortDescription,
			'' SmallImagePath,
			'' LargeImagePath,
			GETDATE() ActivateOn,
			NULL DeactivateOn,
			[dbo].[fn_UrlEncode](C.CategoryName) URLSegment,
			'' MetaKeywords,
			'' MetaDescription,
			'' SortOrder,
			1 ShowDetail,
			dbo.fn_ScrubData(C.CategoryName) PageTitle,
			NULL ContentManagerId,
			NULL DocumentManagerId,
			'' ERPProductValues,
			0 IsFeatured,
			0 IsDynamic,
			NULL RuleManagerId,
			dbo.fn_ScrubData(C.CategoryName) ImageAltText,
			GETDATE() CreatedOn,
			@UserName CreatedBy,
			GETDATE() ModifiedOn,
			@UserName ModifiedBy,
			ISNULL(Path,'') Path,
			ISNULL(ParentPath,'') ParentPath
			FROM dbo.vw_Category C;


--=======================================================================================================================================
	-- Add a DEFAULT category for Non Trade Service Products 
	-- which will have all the Non Trade Service Products assigned and will invisible to the users
--=======================================================================================================================================

		INSERT [dbo].[Category] ([Id], [ParentId], [WebSiteId], [Name], [ShortDescription], [SmallImagePath], [LargeImagePath], 
		[ActivateOn], [DeactivateOn], [UrlSegment], [MetaKeywords], [MetaDescription], [SortOrder], [ShowDetail], 
		[PageTitle], [ContentManagerId], [DocumentManagerId], [ERPProductValues], [IsFeatured], [IsDynamic], 
		[RuleManagerId], [ImageAltText], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy], [Path], [ParentPath]) 
		VALUES (@DefaultCategoryID, NULL, @WebSiteId, N'Default', N'Default', N'', N'', 
		getdate(), NULL, N'Default', N'', N'', 
		0, 1, N'Default', NULL, NULL, 
		N'', 0, 0, NULL, N'Default', 
		getdate(), @UserName, getdate(), @UserName, N'Default', N'')
--=======================================================================================================================================

		-- Grab IDs from existing categories from Insite
		;WITH CTE AS
		(
			SELECT 
				CAST('' AS NVARCHAR(255)) Parent,
				C.Id,
				C.ParentId,
				C.Name
			FROM [Insite.ExpressPipe]..Category c
			WHERE ParentId IS NULL
			UNION ALL SELECT 
				--CAST(C0.Parent + N'|' + C0.Name AS NVARCHAR(255)) Parent,
				Cast([dbo].[fn_GetCategoryFullPathInsite](C.ParentId) as nvarchar(255)) Parent,
				C.Id,
				C0.ParentID,
				C.Name
			FROM [Insite.Expresspipe]..Category c
			JOIN CTE C0 ON C0.Id = c.ParentId
		)

		UPDATE Category
		SET 
			ID = c1.ID,
			ParentId = c2.ID		--SELECT *
		FROM CTE
		--JOIN Category C ON C.Path =   CASE WHEN CTE.ParentId IS NOT NULL THEN SUBSTRING(CTE.Parent,2,len(CTE.Parent))  + '|' ELSE '' END + CTE.Name
		JOIN [Insite.ExpressPipe]..Category c1 ON C1.ID = CTE.ID
		JOIN Category C ON C.Path =  [dbo].[fn_GetCategoryFullPathInsite](C1.Id)
		LEFT OUTER JOIN [Insite.ExpressPipe]..Category c2 ON C2.ID = CTE.ParentId

		-- Update the remaining parentIDs
		UPDATE C
		SET C.ParentID = C1.Id
		--SELECT C.ParentID,  C1.Id, C.ParentPath
		FROM Category C
		JOIN Category C1 ON C1.Path = C.ParentPath
		--JOIN Category C1 ON [dbo].[fn_GetCategoryFullPathETL](C1.Id) = [dbo].[fn_GetCategoryFullPathETL](C.ParentId)
		WHERE C.ParentID IS NULL
		AND C.ParentPath <> ''
		--AND [dbo].[fn_GetCategoryFullPathETL](C.ParentId) <> ''

--###############################################################################################################################
--						TABLE CATEGORY PRODUCT
--###############################################################################################################################
			TRUNCATE TABLE [dbo].[CategoryProduct];

			INSERT INTO [dbo].[CategoryProduct]
				   (Id
				   ,[CategoryId]
				   ,[ProductId]
				   ,[SortOrder]
				   ,[CreatedOn]
				   ,[CreatedBy]
				   ,[ModifiedOn]
				   ,[ModifiedBy])
		    SELECT 
					NEWID() as Id,
					CategoryId,
					ProductId,
					SortOrder,
					GETDATE() as CreatedOn,
					@UserName as CreatedBy,
					GETDATE() as ModifiedOn,
					@UserName as ModifiedBy
			  FROM  vw_CategoryProduct

			-- Tap existing Category Product Id from the InsiteExpressPipe CategoryProduct table
			--	and update back to ETL
			  UPDATE ETL_CP
			     SET Id = IXP_CP.Id
			    FROM [insite.expresspipe]..CategoryProduct IXP_CP
		  INNER JOIN ETL_ECommerce..CategoryProduct ETL_CP
		          ON (IXP_CP.ProductId = ETL_CP.ProductId
				 AND IXP_CP.CategoryId = ETL_CP.CategoryId)
--=======================================================================================================================================
--Add a category property for Non Trade Service Products
--=======================================================================================================================================
		INSERT INTO [dbo].[CategoryProduct]
				   (Id
				   ,[CategoryId]
				   ,[ProductId]
				   ,[SortOrder]
				   ,[CreatedOn]
				   ,[CreatedBy]
				   ,[ModifiedOn]
				   ,[ModifiedBy])
		    SELECT 
					NEWID() as Id,
					@DefaultCategoryID,
					P.ID as ProductId,
					0 SortOrder,
					GETDATE() as CreatedOn,
					@UserName as CreatedBy,
					GETDATE() as ModifiedOn,
					@UserName as ModifiedBy
			  FROM Product P 
			  INNER JOIN ProductProperty PP ON PP.ProductId = P.ID 
			  WHERE PP.Name = 'IsNonTSP' AND PP.Value = 'Yes'
--=======================================================================================================================================
END