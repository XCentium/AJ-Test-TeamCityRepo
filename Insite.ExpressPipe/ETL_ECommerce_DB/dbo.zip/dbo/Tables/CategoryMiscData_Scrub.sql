﻿CREATE TABLE [dbo].[CategoryMiscData_Scrub] (
    [ERPNumber]        NVARCHAR (50)   NULL,
    [Small Image]      NVARCHAR (255)  NULL,
    [Long Description] NVARCHAR (2500) NULL
);

