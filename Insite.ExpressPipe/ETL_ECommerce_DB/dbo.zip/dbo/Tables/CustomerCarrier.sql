﻿CREATE TABLE [dbo].[CustomerCarrier] (
    [CustomerId] UNIQUEIDENTIFIER NOT NULL,
    [CarrierId]  UNIQUEIDENTIFIER NOT NULL
);

